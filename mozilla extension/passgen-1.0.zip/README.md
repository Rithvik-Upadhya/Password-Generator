# Password Generator

Hosted on [Netlify](https://clinquant-douhua-868330.netlify.app/)

Built using vanilla Javascript, HTML, and CSS
